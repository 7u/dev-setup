## APACHE2 MACPORTS PLUGIN


---

### FEATURES

| Alias          | Function                                                                       | Description           |
|:--------------:|:-------------------------------------------------------------------------------|----------------------:|
| apache2restart | sudo /opt/local/etc/LaunchDaemons/org.macports.apache2/apache2.wrapper restart | Restart apache daemon |
| apache2start   | sudo /opt/local/etc/LaunchDaemons/org.macports.apache2/apache2.wrapper start   | Start apache daemon   |
| apache2stop    | sudo /opt/local/etc/LaunchDaemons/org.macports.apache2/apache2.wrapper stop    | Stop apache daemon    |

---

### CONTRIBUTORS
 - Alexander Rinass (alex@rinass.net)

---
